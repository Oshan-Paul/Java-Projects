public class TriangleArea {
    public static void main(String[] args) {
        double base = Double.parseDouble(args[0]);
        double height = Double.parseDouble(args[1]);
        double area = 0.5 * base * height;
        System.out.println("Area of the Triangle: " + area);
    }
}
