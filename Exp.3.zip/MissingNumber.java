import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class MissingNumber {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;

        // Ensuring valid input for array size
        while (true) {
            System.out.print("Enter the number of elements (N-1, must be ≥ 1): ");
            if (sc.hasNextInt()) {
                n = sc.nextInt();
                if (n >= 1) break;
            } else {
                sc.next(); // Clear invalid input
            }
            System.out.println("Invalid input. Please enter a valid integer ≥ 1.");
        }

        int[] arr = new int[n];
        Set<Integer> enteredNumbers = new HashSet<>();
        int N = n + 1; // Total numbers including the missing one

        System.out.println("Enter " + n + " unique numbers from 1 to " + N + ":");

        for (int i = 0; i < n; i++) {
            while (true) {
                if (sc.hasNextInt()) {
                    int num = sc.nextInt();

                    if (num >= 1 && num <= N && !enteredNumbers.contains(num)) {
                        arr[i] = num;
                        enteredNumbers.add(num);
                        break;
                    } else {
                        System.out.println("Invalid number. Enter a unique number between 1 and " + N);
                    }
                } else {
                    System.out.println("Invalid input. Enter an integer.");
                    sc.next(); // Clear invalid input
                }
            }
        }

        // Calculating missing number
        int expectedSum = N * (N + 1) / 2;
        int actualSum = 0;
        for (int num : arr) {
            actualSum += num;
        }

        System.out.println("Missing number: " + (expectedSum - actualSum));
        sc.close();
    }
}


/*
Valid input:

mathematica
Copy
Edit
Enter the number of elements (N-1, must be ≥ 1): 5
Enter 5 unique numbers from 1 to 6:
1 2 3 5 6
Missing number: 4


Handles duplicates or out-of-range values:

mathematica
Copy
Edit
Enter the number of elements (N-1, must be ≥ 1): 5
Enter 5 unique numbers from 1 to 6:
1 2 2
Invalid number. Enter a unique number between 1 and 6
3 5 6
Missing number: 4


Handles non-numeric input:

pgsql
Copy
Edit
Enter the number of elements (N-1, must be ≥ 1): abc
Invalid input. Please enter a valid integer ≥ 1.
Enter the number of elements (N-1, must be ≥ 1): 5
Enter 5 unique numbers from 1 to 6:
1 2 xyz
Invalid input. Enter an integer.
3 5 6
Missing number: 4 */