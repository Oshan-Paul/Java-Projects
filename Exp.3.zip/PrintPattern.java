public class PrintPattern {
    public static void main(String[] args) {
        String[] pattern = {"?", "# # #", "? ? ? ? ?", "# # # # # # #", "? ? ? ? ? ? ? ? ?"};
        for (String row : pattern) {
            System.out.println(row);
        }
    }
}
