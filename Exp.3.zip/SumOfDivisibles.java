import java.util.Scanner;

public class SumOfDivisibles {
    public static int sumOfDivisibles(int x, int y) {
        int divisor = 18;

        if (x > y) {
            int temp = x;
            x = y;
            y = temp;
        }

        int start = (x % divisor == 0) ? x : x + (divisor - x % divisor);
        int end = y - (y % divisor);

        if (start > end) {
            return 0;
        }

        int n = (end - start) / divisor + 1;
        int totalSum = (n * (start + end)) / 2;

        return totalSum;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the starting value (x): ");
        int x = scanner.nextInt();
        System.out.print("Enter the ending value (y): ");
        int y = scanner.nextInt();
        scanner.close();

        int result = sumOfDivisibles(x, y);
        System.out.println("The sum of all integers between " + x + " and " + y + " that are divisible by both 6 and 9 is: " + result);
    }
}
