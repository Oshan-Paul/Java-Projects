import java.util.Arrays;
import java.util.Scanner;

public class CopyArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;

        // Ensuring valid input for array size
        while (true) {
            System.out.print("Enter the number of elements (must be ≥ 1): ");
            if (sc.hasNextInt()) {
                n = sc.nextInt();
                if (n >= 1) break;
            } else {
                sc.next(); // Clear invalid input
            }
            System.out.println("Invalid input. Please enter a valid integer ≥ 1.");
        }

        int[] original = new int[n];
        int[] copy = new int[n];

        System.out.println("Enter " + n + " elements:");
        for (int i = 0; i < n; i++) {
            while (true) {
                if (sc.hasNextInt()) {
                    original[i] = sc.nextInt();
                    break;
                } else {
                    System.out.println("Invalid input. Enter an integer.");
                    sc.next(); // Clear invalid input
                }
            }
        }

        // Copying array
        for (int i = 0; i < original.length; i++) {
            copy[i] = original[i];
        }

        System.out.println("Copied Array: " + Arrays.toString(copy));
        sc.close();
    }
}

/*

Valid input:

mathematica
Copy
Edit
Enter the number of elements (must be ≥ 1): 5
Enter 5 elements:
1 2 3 4 5
Copied Array: [1, 2, 3, 4, 5]


Handles non-integer input:

mathematica
Copy
Edit
Enter the number of elements (must be ≥ 1): abc
Invalid input. Please enter a valid integer ≥ 1.
Enter the number of elements (must be ≥ 1): 3
Enter 3 elements:
10 xyz
Invalid input. Enter an integer.
20 30
Copied Array: [10, 20, 30]
 */