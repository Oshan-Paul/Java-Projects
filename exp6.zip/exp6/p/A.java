package p;

public class A {
    public void publicMethod() {
        System.out.println("Public Method in A");
    }

    protected void protectedMethod() {
        System.out.println("Protected Method in A");
    }

    void defaultMethod() {
        System.out.println("Default Method in A");
    }

    private void privateMethod() {
        System.out.println("Private Method in A");
    }
}


