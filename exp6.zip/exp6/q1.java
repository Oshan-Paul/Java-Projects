import Balance.Account;

public class q1 {
    public static void main(String[] args) {
        Account acc = new Account(1000.50);
        acc.Display_Balance();
    }
}
