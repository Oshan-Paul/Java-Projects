import shapes.Circle;

public class q3 {
    public static void main(String[] args) {
        Circle c = new Circle();
        c.displayPI();
        c.calculateArea(5);

    }
}