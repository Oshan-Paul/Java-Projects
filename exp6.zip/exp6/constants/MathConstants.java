package constants;

public class MathConstants {
    public final double PI = 3.14159;

    public final void displayPI() {
        System.out.println("Value of PI: " + PI);
    }
}