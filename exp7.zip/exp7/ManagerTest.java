abstract class Employee {
    String name;
    String role;

    Employee(String name, String role) {
        this.name = name;
        this.role = role;
    }

    abstract void calculateSalary();
    abstract void displayDetails();
}

class Manager extends Employee {
    private double salary;

    Manager(String name, double salary) {
        super(name, "Manager");
        this.salary = salary;
    }

    @Override
    void calculateSalary() {
        System.out.println("Manager Salary: " + salary);
    }

    @Override
    void displayDetails() {
        System.out.println("Name: " + name + ", Role: " + role + ", Salary: " + salary);
    }
}

public class ManagerTest {
    public static void main(String[] args) {
        Manager manager = new Manager("Alice", 70000);
        manager.calculateSalary();
        manager.displayDetails();
    }
}



