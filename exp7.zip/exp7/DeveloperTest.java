class Developer extends Employee {
    private double hourlyRate;
    private int hoursWorked;

    Developer(String name, double hourlyRate, int hoursWorked) {
        super(name, "Developer");
        this.hourlyRate = hourlyRate;
        this.hoursWorked = hoursWorked;
    }

    @Override
    void calculateSalary() {
        System.out.println("Developer Salary: " + (hourlyRate * hoursWorked));
    }

    @Override
    void displayDetails() {
        System.out.println("Name: " + name + ", Role: " + role + ", Salary: " + (hourlyRate * hoursWorked));
    }
}

public class DeveloperTest {
    public static void main(String[] args) {
        Developer developer = new Developer("Bob", 50, 160);
        developer.calculateSalary();
        developer.displayDetails();
    }
}
