abstract class Shape {
    abstract void calculateArea();
}

class Rectangle extends Shape {
    private double length, width;

    Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    @Override
    void calculateArea() {
        System.out.println("Rectangle Area: " + (length * width));
    }
}

class Circle extends Shape {
    private double radius;

    Circle(double radius) {
        this.radius = radius;
    }

    @Override
    void calculateArea() {
        System.out.println("Circle Area: " + (Math.PI * radius * radius));
    }
}

public class ShapeTest {
    public static void main(String[] args) {
        Shape rect = new Rectangle(5, 4);
        rect.calculateArea();

        Shape circle = new Circle(3);
        circle.calculateArea();
    }
}